from django.http import HttpResponse
from django.shortcuts import render
def home(request):
    return render(request, 'index.html')
def brithday(request):
    chek = request.POST.get('text', 'nothing')
    if chek=='Alonendhappy' or chek=='special':
        return render(request, 'brithday.html')
    else:
        return render(request, 'not.html')
